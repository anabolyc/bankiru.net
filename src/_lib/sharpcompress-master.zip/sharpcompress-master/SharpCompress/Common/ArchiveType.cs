﻿namespace SharpCompress.Common
{
    public enum ArchiveType
    {
        Rar,
        Zip,
        Tar,
        SevenZip,
        GZip,
    }
}
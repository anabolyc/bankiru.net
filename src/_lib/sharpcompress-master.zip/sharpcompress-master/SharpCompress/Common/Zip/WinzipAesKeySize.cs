﻿namespace SharpCompress.Common.Zip
{
    internal enum WinzipAesKeySize
    {
        KeySize128 = 1,
        KeySize192 = 2,
        KeySize256 = 3,
    }
}
﻿namespace SharpCompress.Common.SevenZip
{
    internal class CBindPair
    {
        internal int InIndex;
        internal int OutIndex;
    }
}
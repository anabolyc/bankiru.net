﻿
namespace Org.BouncyCastle.Crypto
{
    public interface ICipherParameters
    {
    }
}
﻿namespace SharpCompress.Compressor.LZMA.Utilites
{
    internal interface IPasswordProvider
    {
        string CryptoGetTextPassword();
    }
}